import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { GestureComponent } from './gesture/gesture.component';
import { ProfileDetailsComponent } from './profile-details/profile-details.component';

export const routes: Routes = [
    { path: 'home', component: HomeComponent },
  { path: 'gesture', component: GestureComponent },
  { path: 'profile-details/:id', component: ProfileDetailsComponent },
  { path: '', redirectTo: '/home', pathMatch: 'full' }
];
