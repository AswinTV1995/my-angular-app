import { Component, OnInit } from '@angular/core';
import { ProfileService } from '../services/profile.service';
import { Router } from '@angular/router';
import { NgFor, NgIf } from '@angular/common';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [ NgFor, NgIf ],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  profiles: any[] = [];
  showToast = false;  // For toast visibility
  toastMessage = '';  // Toast message

  constructor(
    private profileService: ProfileService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.profiles = this.profileService.getProfiles();
  }

  removeProfile(profile: any, action: string): void {
    this.profileService.removeProfile(profile.id);
    this.profiles = this.profileService.getProfiles(); // Refresh profiles after removing
    this.showCustomToast(`${profile.name} removed (${action})`);
  }

  viewProfile(profile: any): void {
    this.router.navigate(['/profile-details', profile.id]);
  }

  showCustomToast(message: string): void {
    this.toastMessage = message;
    this.showToast = true;
    setTimeout(() => {
      this.showToast = false;
    }, 2000);  // Hides the toast after 2 seconds
  }
}
