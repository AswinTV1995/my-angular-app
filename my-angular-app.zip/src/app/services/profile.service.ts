import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {
  profiles = [
    {
      id: 1,
      name: 'Priyanka',
      age: '27 Yrs, 5 ft 2 in',
      description: 'Tamil, Nair, MBBS, Doctor, Chennai, Tamil Nadu, India',
      image: 'assets/images/priyanka.jpg',
      photos: ['/assets/images/photo1.jpg', 'assets/images/photo2.jpg']
    },
    {
      id: 2,
      name: 'Pragati',
      age: '27 Yrs, 5 ft 5 in',
      description: 'Poosam, Hindu, Kayastha, Doctor, Chennai, Tamil Nadu',
      image: 'assets/images/pragati.jpg',
      photos: ['assets/images/photo3.jpg', 'assets/images/photo4.jpg']
    },
    {
      id: 3,
      name: 'Aiswarya',
      age: '26 Yrs, 5 ft 4 in',
      description: 'Tamil, MBBS, Doctor, Chennai, Tamil Nadu, India',
      image: 'assets/images/aiswarya.jpg',
      photos: ['assets/images/photo5.jpg', 'assets/images/photo6.jpg']
    },
    // Add more profiles as needed
  ];

  // Get all profiles
  getProfiles() {
    return this.profiles;
  }

  // Remove a profile by id
  removeProfile(id: number) {
    this.profiles = this.profiles.filter(profile => profile.id !== id);
  }

  // Get a single profile by id
  getProfileById(id: number) {
    return this.profiles.find(profile => profile.id === id);
  }
}
