import { Component, OnInit } from '@angular/core';
import { ProfileService } from '../services/profile.service';
import { Router } from '@angular/router';
import { NgFor, NgIf } from '@angular/common';

@Component({
  selector: 'app-gesture',
  standalone: true,
  imports: [ NgFor, NgIf ],
  templateUrl: './gesture.component.html',
  styleUrls: ['./gesture.component.scss']
})
export class GestureComponent implements OnInit {
  profiles: any[] = [];
  showToast = false;  // For toast visibility
  toastMessage = '';  // Toast message

  constructor(
    private profileService: ProfileService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.profiles = this.profileService.getProfiles();
  }

  removeProfile(profile: any, action: string): void {
    this.profileService.removeProfile(profile.id);
    this.profiles = this.profileService.getProfiles();
    this.showCustomToast(`${profile.name} removed (${action})`);
    // this.snackBar.open(`${profile.name} removed (${action})`, 'Close', {
    //   duration: 2000,
    // });
  }

  goBack(): void {
    this.router.navigate(['/home']);
  }

  showCustomToast(message: string): void {
    this.toastMessage = message;
    this.showToast = true;
    setTimeout(() => {
      this.showToast = false;
    }, 2000);  // Hides the toast after 2 seconds
  }
}
